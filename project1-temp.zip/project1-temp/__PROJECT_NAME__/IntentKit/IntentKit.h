//
//  IntentKit.h
//  IntentKit
//
//  Created by Mac on 2020-06-20.
//

#import <Foundation/Foundation.h>
// #import "IntentKit/ControlBlindIntent.h"
#import "IntentKit/ActivateSceneIntent.h"

//! Project version number for IntentKit.
FOUNDATION_EXPORT double IntentKitVersionNumber;

//! Project version string for IntentKit.
FOUNDATION_EXPORT const unsigned char IntentKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IntentKit/PublicHeader.h>


